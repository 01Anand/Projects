import psycopg2

conn = psycopg2.connect(
    dbname="rqms",
    user="rqms",
    password="Rqms_123",
    host="SRV613981.HSTGR.CLOUD",
    port="5432"
)

def insert_template(metadata, s3_url):
    with conn.cursor() as cursor:
        cursor.execute("SELECT nextval('r_template_seq')")
        v_temp_id = cursor.fetchone()[0]
        cursor.execute("""
            INSERT INTO r_template (template_id, id_prefix, title, version, status, sections, training, training_on_each_version, periodic_review, review_limit, download_by, effective_on_approval, show_sections, aws_s3_url, created_date, created_by, updated_date, updated_by)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP, %s, CURRENT_TIMESTAMP, %s)
        """, (v_temp_id, f'SD-{v_temp_id}', 'Standard Doc', 1.0, 'A', metadata, 'Y', 'Y', 3, 10, 'ADMIN', 'Y', 'Y', s3_url, 'ADMIN', 'ADMIN'))
        conn.commit()
    return v_temp_id

def fetch_template_metadata(template_id):
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM r_template WHERE template_id = %s AND status = 'A'", (template_id,))
        return cursor.fetchone()

def update_template(template_id, metadata, s3_url):
    with conn.cursor() as cursor:
        cursor.execute("SELECT version FROM r_template WHERE template_id = %s AND status = 'A'", (template_id,))
        version = cursor.fetchone()[0]
        cursor.execute("UPDATE r_template SET status = 'I' WHERE template_id = %s AND status = 'A'", (template_id,))
        cursor.execute("""
            INSERT INTO r_template (template_id, id_prefix, title, version, status, sections, training, training_on_each_version, periodic_review, review_limit, download_by, effective_on_approval, show_sections, aws_s3_url, created_date, created_by, updated_date, updated_by)
            VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, CURRENT_TIMESTAMP, %s, CURRENT_TIMESTAMP, %s)
        """, (template_id, f'SD-{template_id}', 'Standard Doc', version + 1.0, 'A', metadata, 'Y', 'Y', 3, 10, 'ADMIN', 'Y', 'Y', s3_url, 'ADMIN', 'ADMIN'))
        conn.commit()
    return template_id

def fetch_all_templates():
    with conn.cursor() as cursor:
        cursor.execute("SELECT * FROM r_template WHERE status = 'A'")
        return cursor.fetchall()