
import boto3

s3_client = boto3.client('s3')

def upload_file_to_s3(file, bucket_name, file_name):
    s3_client.upload_fileobj(file.file, bucket_name, file_name)
    return f"s3://{bucket_name}/{file_name}"

def fetch_file_from_s3(bucket_name, file_name):
    return s3_client.get_object(Bucket=bucket_name, Key=file_name)