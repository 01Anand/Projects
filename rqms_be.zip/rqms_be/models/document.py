from pydantic import BaseModel
from typing import List, Optional
from models.metadata import Metadata

class Document(BaseModel):
    name: str
    content: str
    metadata: Metadata

class DocumentUpdate(BaseModel):
    name: Optional[str]
    content: Optional[str]