from pydantic import BaseModel
from typing import List

class Metadata(BaseModel):
    tags: List[str]
    author: str