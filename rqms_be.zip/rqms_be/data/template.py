from dataclasses import dataclass
from datetime import datetime

@dataclass
class Template:
    template_id: int
    id_prefix: str
    title: str
    version: float
    status: str
    sections: str
    training: str
    training_on_each_version: str
    periodic_review: int
    review_limit: int
    download_by: str
    effective_on_approval: str
    show_sections: str
    aws_s3_url: str
    created_date: datetime
    created_by: str
    updated_date: datetime
    updated_by: str