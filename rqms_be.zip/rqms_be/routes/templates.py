from fastapi import APIRouter, File, Form, UploadFile, HTTPException
from fastapi.responses import JSONResponse
from utils.s3_utils import upload_file_to_s3, fetch_file_from_s3
from utils.db_utils import insert_template, fetch_template_metadata, update_template, fetch_all_templates

router = APIRouter()

@router.post("/upload_template")
async def upload_template(file: UploadFile = File(...), metadata: str = Form(...)):
    s3_url = upload_file_to_s3(file, 'rqmsdoc', file.filename)
    try:
        v_temp_id = insert_template(metadata, s3_url)
        return JSONResponse(content={"status": "success", "template_id": v_temp_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/fetch_template")
async def fetch_template(template_id: int):
    try:
        metadata = fetch_template_metadata(template_id)
        file = fetch_file_from_s3('your_bucket_name', metadata['aws_s3_url'].split('/')[-1])
        return JSONResponse(content={"file": file, "metadata": metadata})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/update_template")
async def update_template_route(file: UploadFile = File(...), metadata: str = Form(...), template_id: int = Form(...)):
    s3_url = upload_file_to_s3(file, 'your_bucket_name', file.filename)
    try:
        v_temp_id = update_template(template_id, metadata, s3_url)
        return JSONResponse(content={"status": "success", "template_id": v_temp_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/get_template_metadata")
async def get_template_metadata(template_id: int):
    try:
        if template_id == 0:
            metadata = fetch_all_templates()
        else:
            metadata = fetch_template_metadata(template_id)
        return JSONResponse(content={"status": "success", "metadata": metadata})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))