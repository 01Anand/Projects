from fastapi import APIRouter, HTTPException, UploadFile, File, Form
from models.document import Document, DocumentUpdate
from typing import List, Optional
import boto3
import uuid
 

from fastapi.responses import JSONResponse
from utils.s3_utils import upload_file_to_s3, fetch_file_from_s3
from utils.db_utils import insert_template, fetch_template_metadata, update_template, fetch_all_templates




router = APIRouter()

# In-memory storage for demonstration purposes
documents = {}
document_versions = {}

# Initialize S3 client
s3_client = boto3.client('s3')
BUCKET_NAME = 'rqmsdoc'

@router.post("/", status_code=201)
def create_document(doc: Document):
    doc_id = str(uuid.uuid4())
    documents[doc_id] = doc.dict()
    return {"id": doc_id, **doc.dict()}

@router.get("/{document_id}")
def get_document(document_id: str):
    if document_id not in documents:
        raise HTTPException(status_code=404, detail="Document not found")
    return {"id": document_id, **documents[document_id]}

@router.put("/{document_id}")
def update_document(document_id: str, doc: DocumentUpdate):
    if document_id not in documents:
        raise HTTPException(status_code=404, detail="Document not found")
    documents[document_id].update(doc.dict(exclude_unset=True))
    return {"id": document_id, **documents[document_id]}

@router.delete("/{document_id}", status_code=204)
def delete_document(document_id: str):
    if document_id not in documents:
        raise HTTPException(status_code=404, detail="Document not found")
    del documents[document_id]
    return

@router.get("/search")
def search_documents(q: Optional[str] = None, tags: Optional[str] = None, author: Optional[str] = None, created_at_gte: Optional[str] = None, created_at_lte: Optional[str] = None):
    results = []
    for doc_id, doc in documents.items():
        if q and q not in doc['name'] and q not in doc['content']:
            continue
        if tags and not set(tags.split(',')).intersection(set(doc['metadata']['tags'])):
            continue
        if author and author != doc['metadata']['author']:
            continue
        results.append({"id": doc_id, **doc})
    return {"results": results}

@router.get("/{document_id}/download")
def download_document(document_id: str):
    if document_id not in documents:
        raise HTTPException(status_code=404, detail="Document not found")
    # Assuming the document content is stored in S3
    s3_key = f"documents/{document_id}.pdf"
    url = s3_client.generate_presigned_url('get_object', Params={'Bucket': BUCKET_NAME, 'Key': s3_key}, ExpiresIn=3600)
    return {"url": url}

@router.post("/upload", status_code=201)
def upload_document(file: UploadFile = File(...), name: str = Form(...)):
    doc_id = str(uuid.uuid4())
    s3_key = f"documents/{doc_id}/{file.filename}"
    s3_client.upload_fileobj(file.file, BUCKET_NAME, s3_key)
    documents[doc_id] = {"name": name, "content": s3_key, "metadata": {"tags": [], "author": ""}}
    return {"id": doc_id, "name": name, "content": s3_key}

@router.post("/{document_id}/versions", status_code=201)
def create_document_version(document_id: str, content: str):
    if document_id not in documents:
        raise HTTPException(status_code=404, detail="Document not found")
    version_id = str(uuid.uuid4())
    if document_id not in document_versions:
        document_versions[document_id] = []
    document_versions[document_id].append({"id": version_id, "content": content, "created_at": "2023-12-31T23:59:59Z"})
    return {"id": version_id, "document_id": document_id, "content": content, "created_at": "2023-12-31T23:59:59Z"}

@router.get("/{document_id}/versions/{version_id}")
def get_document_version(document_id: str, version_id: str):
    if document_id not in document_versions:
        raise HTTPException(status_code=404, detail="Document not found")
    for version in document_versions[document_id]:
        if version["id"] == version_id:
            return version
    raise HTTPException(status_code=404, detail="Version not found")

@router.get("/{document_id}/versions/latest")
def get_latest_document_version(document_id: str):
    if document_id not in document_versions or not document_versions[document_id]:
        raise HTTPException(status_code=404, detail="No versions found")
    return document_versions[document_id][-1]

@router.get("/{document_id}/versions")
def list_document_versions(document_id: str):
    if document_id not in document_versions:
        raise HTTPException(status_code=404, detail="No versions found")
    return document_versions[document_id]

@router.put("/{document_id}/versions/{version_id}/rollback")
def rollback_document_version(document_id: str, version_id: str):
    if document_id not in document_versions:
        raise HTTPException(status_code=404, detail="Document not found")
    for version in document_versions[document_id]:
        if version["id"] == version_id:
            documents[document_id]["content"] = version["content"]
            return {"status": "success"}
    raise HTTPException(status_code=404, detail="Version not found")

@router.get("/{document_id}/versions/{version_id1}/compare/{version_id2}")
def compare_document_versions(document_id: str, version_id1: str, version_id2: str):
    if document_id not in document_versions:
        raise HTTPException(status_code=404, detail="Document not found")
    version1 = next((v for v in document_versions[document_id] if v["id"] == version_id1), None)
    version2 = next((v for v in document_versions[document_id] if v["id"] == version_id2), None)
    if not version1 or not version2:
        raise HTTPException(status_code=404, detail="Version not found")
    # Simple comparison logic for demonstration purposes
    changes = []
    if version1["content"] != version2["content"]:
        changes.append({"type": "modification", "path": "content", "old_value": version1["content"], "new_value": version2["content"]})
    return {"changes": changes}


# cretae 
@router.post("/upload_template")
async def upload_template(file: UploadFile = File(...), metadata: str = Form(...)):
    s3_url = upload_file_to_s3(file, 'rqmsdoc', file.filename)
    try:
        v_temp_id = insert_template(metadata, s3_url)
        return JSONResponse(content={"status": "success", "template_id": v_temp_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/fetch_template")
async def fetch_template(template_id: int):
    try:
        metadata = fetch_template_metadata(template_id)
        file = fetch_file_from_s3('your_bucket_name', metadata['aws_s3_url'].split('/')[-1])
        return JSONResponse(content={"file": file, "metadata": metadata})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/update_template")
async def update_template_route(file: UploadFile = File(...), metadata: str = Form(...), template_id: int = Form(...)):
    s3_url = upload_file_to_s3(file, 'your_bucket_name', file.filename)
    try:
        v_temp_id = update_template(template_id, metadata, s3_url)
        return JSONResponse(content={"status": "success", "template_id": v_temp_id})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/get_template_metadata")
async def get_template_metadata(template_id: int):
    try:
        if template_id == 0:
            metadata = fetch_all_templates()
        else:
            metadata = fetch_template_metadata(template_id)
        return JSONResponse(content={"status": "success", "metadata": metadata})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))